
import java.util.ArrayList;
import java.util.Random;

public class SimulatedAnnealing {

	// Each slot belongs to a class which contains an 2d array with the week
	// schedule
	// of this class
	public static ArrayList<Class> schedule = new ArrayList<Class>();

	// A list with all the teachers
	static ArrayList<Teacher> teachers = new ArrayList<Teacher>();

	// A list with all the lessons
	static ArrayList<Lesson> lessons = new ArrayList<Lesson>();

	// Maximum temperature
	static final double Tmax = 100;

	// Minimum temperature
	static final double Tmin = 1;

	// Current temperature
	static double T = Tmax;

	// Rate of decrease of temperature
	static final double alpha = 0.96;

	/**
	 * Generate initial state
	 * 
	 * @return all the classes with their schedules initialized
	 */
	public static ArrayList<Class> genInitSol() {

		int hour, day;
		Lecture lecture;

		for (Class cl : schedule) {

			hour = 0;
			day = 0;
			Teacher teacher;
			for (Lesson l : lessons) {
				if (l.getClasses().charAt(0) == (cl.getName().charAt(0))) {
					teacher = null;

					for (Teacher t : teachers) {
						for (int i = 0; i < t.getLessonID().length; i++) {
							if (l.getID().equals(t.getLessonID()[i])) {
								teacher = t;
								break;
							}
						}
					}

					for (int i = 0; i < l.getHours(); i++) {

						lecture = new Lecture(teacher, l);
						cl.setTimetable(hour, day, lecture);

						hour++;
						if (hour == 7) {

							day++;
							hour = 0;
						}
					}
				}
			}
		}

		for (Teacher t : teachers)
			t.setSchedule();

		return schedule;
	}

	/*
	 * For each class swap two lectures
	 * 
	 * @param currentSol : All the classes with their schedules
	 * 
	 * @return all the classes with their new schedules
	 */
	public static ArrayList<Class> neighbor(ArrayList<Class> currentSol) {

		Random r = new Random();
		int a, b, c, d;

		for (Class cl : currentSol) {

			a = r.nextInt(7);
			b = r.nextInt(5);
			c = r.nextInt(7);
			d = r.nextInt(5);

			while (a == c && d == b) {
				a = r.nextInt(7);
				b = r.nextInt(5);
				c = r.nextInt(7);
				d = r.nextInt(5);
			}

			cl.swap(a, b, c, d);
		}

		return currentSol;

	}

	/*
	 * �euristic function, check restrictions and calculate score of a solution
	 * 
	 * @param s : All the classes with their schedules
	 * 
	 * @return how many restrictions are broken
	 */
	public static int score(ArrayList<Class> s) {
		int i;
		int j;
		int a, b;
		int v = 0;
		int day1 = 0;
		int day2 = 0;
		int day3 = 0;
		int day4 = 0;
		int day5 = 0;
		Class class1, class2;

		// 6th restriction
		for (int k = 0; k < s.size(); k++)
			for (int l = k + 1; l < s.size(); l++) {

				class1 = s.get(k);
				class2 = s.get(l);

				for (i = 0; i < class1.getTimetable().length; i++)
					for (j = 0; j < class2.getTimetable()[0].length; j++)
						if (class1.getTimetable()[i][j] != null && class2.getTimetable()[i][j] != null)
							if ((class1.getTimetable()[i][j].getTeacher())
									.equals(class2.getTimetable()[i][j].getTeacher()))
								return Integer.MAX_VALUE;
			}

		// 1st restriction
		for (Class c : s)
			for (i = 0; i < 5; i++) {

				j = 0;

				while (j < 7) {

					while ((c.getTimetable()[i][j]) == null && j < 7)
						j++;

					while ((c.getTimetable()[i][j]) != null && j < 7)
						j++;

					a = j;

					while ((c.getTimetable()[i][j]) == null && j < 7)
						j++;

					b = j;

					if (i < 7) {
						v += b - a;
						j = b;
					}
				}
			}

		// 2nd restriction
		for (Teacher t : teachers)
			for (j = 0; j < 5; j++)
				if (t.foundThreeConsecutiveHours(j))
					v++;

		// 3rd restriction
		for (i = 0; i < 5; i++) {
			for (Class c2 : s) {
				for (i = 0; i < c2.getTimetable().length; i++)
					for (j = 0; j < c2.getTimetable()[0].length; j++) {
						if (c2.getTimetable()[i][j] != null) {

							if (i == 0)
								day1++;
							if (i == 1)
								day2++;
							if (i == 2)
								day3++;
							if (i == 3)
								day4++;
							if (i == 4)
								day5++;
						}

					}

				if (Math.abs(day1 - day2) > 3)
					v++;
				if (Math.abs(day1 - day3) > 3)
					v++;
				if (Math.abs(day1 - day4) > 3)
					v++;
				if (Math.abs(day1 - day5) > 3)
					v++;
				if (Math.abs(day2 - day3) > 3)
					v++;
				if (Math.abs(day2 - day4) > 3)
					v++;
				if (Math.abs(day2 - day5) > 3)
					v++;
				if (Math.abs(day3 - day4) > 3)
					v++;
				if (Math.abs(day4 - day5) > 3)
					v++;
			}
		}

		// 4th restriction
		for (Class c3 : s)
			for (i = 0; i < c3.getTimetable().length; i++)
				for (j = 0; j < c3.getTimetable()[0].length; j++)
					for (int k = i; k < c3.getTimetable().length; k++)
						if ((c3.getTimetable()[i][j]).equals(c3.getTimetable()[k][j]))
							v++;

		// 5th restriction
		for (int t1 = 0; t1 < teachers.size(); t1++)
			for (int t2 = t1 + 1; t2 < teachers.size(); t2++)
				if (Math.abs(teachers.get(t1).calculateTotalWorkingHours()
						- teachers.get(t2).calculateTotalWorkingHours()) > 10)
					v++;

		return v;

	}

	/*
	 * Use simulated annealing to create a schedule that breaks the least amount of
	 * restrictions
	 */
	public static void runSimulatedAnnealing() {

		// Initial state
		ArrayList<Class> currentSol = genInitSol();

		while (T > Tmin) {

			ArrayList<Class> newSol = neighbor(currentSol);
			double ap = Math.pow(Math.E, (score(currentSol) - score(newSol)) / T);
			if (ap > Math.random())
				currentSol = newSol;

			// decrease temperature
			T *= alpha;
		}

		schedule = currentSol;

	}

	/*
	 * This method must be called in main to return the solution-schedule in a form
	 * of Strings
	 */

	public static ArrayList<String[]> getCompatibleSchedule() {

		ArrayList<String[]> compatibleSchedule = new ArrayList<String[]>();

		for (int i = 0; i < schedule.size(); i++) {

			String[] classWeekCourses = new String[6];
			classWeekCourses[5] = schedule.get(i).getName();

			for (int day = 0; day < 5; day++) {

				String daySchedule = "";

				for (int hour = 0; hour < 7; hour++) {

					if (((schedule.get(i)).getTimetable())[hour][day] != null) {

						Lecture lecture = schedule.get(i).getTimetable()[hour][day];
						String lessonName = lecture.getLesson().getName();
						daySchedule += lessonName;
						daySchedule += " / ";
						String teacherIDName = lecture.getTeacher().getID() + " " + lecture.getTeacher().getName();
						daySchedule += teacherIDName;
					} else {
						daySchedule += " - ";
					}
					if (hour != 6)
						daySchedule += ", ";
				}
				classWeekCourses[day] = daySchedule;
			}

			compatibleSchedule.add(classWeekCourses);
		}

		return compatibleSchedule;
	}

	public ArrayList<Class> getSchedule() {
		return schedule;
	}
}
