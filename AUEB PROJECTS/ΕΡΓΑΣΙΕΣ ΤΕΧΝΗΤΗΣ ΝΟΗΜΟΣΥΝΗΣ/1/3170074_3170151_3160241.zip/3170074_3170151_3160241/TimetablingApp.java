
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;
import java.util.ArrayList;
import java.time.Instant;
import java.time.Duration;

/*
 * The class requires 2 txt's :
 *      lessons.txt (in form Code, Subject, Class, Hours)
 *      teachers.txt (in form Code, Name, Course code, Maximum teaching hours Monday Tuesday Wednesday Thursday Friday Week)
 */
public class TimetablingApp {

	/*
	 * Read files to add lessons and teachers in lists
	 */
	public static void readFiles() {

		File file;

		String lessonsFileName = "lessons.txt";
		String teachersFileName = "teachers.txt";

		try {

			file = new File(lessonsFileName);
			Scanner sc = new Scanner(file);

			Lesson lesson = new Lesson();
			String[] lessonInfo;
			String line;

			while (sc.hasNextLine()) {

				line = sc.nextLine();

				if (line.startsWith("#") || line.isEmpty())
					continue;

				lessonInfo = line.split(", ");

				lesson.setID(lessonInfo[0]);
				lesson.setName(lessonInfo[1]);
				lesson.setClasses(lessonInfo[2]);
				lesson.setHours(Integer.parseInt(lessonInfo[3]));

				SimulatedAnnealing.lessons.add(new Lesson(lesson));

			}

			sc.close();

		} catch (Exception e) {
			System.out.println("Reading " + lessonsFileName + " failed with the following error: ");
			e.printStackTrace();
			Scanner sc3 = new Scanner(System.in);
			System.out.println("Press any key to exit... ");
			String exit = sc3.next();
			sc3.close();
			System.out.println("Program terminated");
			System.exit(-1);
		}

		try {

			file = new File(teachersFileName);
			Scanner sc2 = new Scanner(file);
			String line;
			Teacher teacher = new Teacher();
			String[] teacherInfo;

			while (sc2.hasNextLine()) {

				line = sc2.nextLine();

				if (line.startsWith("#") || line.isEmpty())
					continue;

				teacherInfo = line.split(", ");

				teacher.setID(teacherInfo[0]);
				teacher.setName(teacherInfo[1]);
				teacher.setLessonID(teacherInfo[2].split(" "));
				teacher.setHours(teacherInfo[3].split(" "));

				SimulatedAnnealing.teachers.add(new Teacher(teacher));

			}

			sc2.close();

		} catch (Exception e) {
			System.out.println("Reading " + teachersFileName + " failed with the following error: ");
			e.printStackTrace();
			Scanner sc3 = new Scanner(System.in);
			System.out.println("Press any key to exit... ");
			String exit = sc3.next();
			sc3.close();
			System.out.println("Program terminated");
			System.exit(-1);
		}
	}

	/*
	 * Print schedule as a txt
	 * 
	 * @param schedule : The schedules of all classes
	 */
	public static void outputFile(ArrayList<String[]> schedule) {

		BufferedWriter writer = null;

		String scheduleFileName = "schedule.txt";

		try {

			// Create a temporary file
			File scheduleTXT = new File(scheduleFileName);

			// This will output the full path where the file will be written to
			System.out.print("File is located at : ");
			System.out.println(scheduleTXT.getCanonicalPath());

			writer = new BufferedWriter(new FileWriter(scheduleTXT));

			for (int i = 0; i < schedule.size(); i++) {

				// Write name of class
				writer.write("\t");
				writer.write(schedule.get(i)[schedule.get(i).length - 1] + " ");
				writer.newLine();
				for (int j = 0; j < schedule.get(i).length - 1; j++) {

					// Write day schedule
					if (j == 0) {
						writer.write("Monday: ");
					} else if (j == 1) {
						writer.write("Tuesday: ");
					} else if (j == 2) {
						writer.write("Wednesday: ");
					} else if (j == 3) {
						writer.write("Thursday: ");
					} else if (j == 4) {
						writer.write("Friday: ");
					}
					writer.newLine();
					writer.write(schedule.get(i)[j]);
					writer.newLine();
				}
				writer.newLine();

			}

		} catch (Exception e) {
			System.out.println("Writing " + scheduleFileName + " failed with the following error: ");
			e.printStackTrace();
			Scanner sc3 = new Scanner(System.in);
			System.out.println("Press any key to exit... ");
			String exit = sc3.next();
			sc3.close();
			System.out.println("Program terminated");
			System.exit(-1);
		} finally {
			try {

				// Close the writer regardless of what happens
				writer.close();

			} catch (Exception e) {
				System.out.println("Writing " + scheduleFileName + " failed with the following error: ");
				e.printStackTrace();
				Scanner sc3 = new Scanner(System.in);
				System.out.println("Press any key to exit... ");
				String exit = sc3.next();
				sc3.close();
				System.out.println("Program terminated");
				System.exit(-1);
			}
		}
	}

	public static void main(String args[]) {

		Scanner scan = new Scanner(System.in);

		System.out.println("Timetabling App");

		int A, B, C;

		System.out.print("Give number of grade A classes: ");
		A = scan.nextInt();

		System.out.print("Give number of grade B classes: ");
		B = scan.nextInt();

		System.out.print("Give number of grade C classes: ");
		C = scan.nextInt();

		System.out.println("Creating timetable ... ");

		readFiles();

		long beforeUsedMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();

		Instant start = Instant.now();
		
		Class c;
		for (int i = 0; i < A; i++) {
			c = new Class("A" + (i + 1));
			SimulatedAnnealing.schedule.add(c);
		}
		for (int i = 0; i < B; i++) {
			c = new Class("B" + (i + 1));
			SimulatedAnnealing.schedule.add(c);
		}
		for (int i = 0; i < C; i++) {
			c = new Class("C" + (i + 1));
			SimulatedAnnealing.schedule.add(c);
		}

		SimulatedAnnealing.runSimulatedAnnealing();

		Instant finish = Instant.now();

		long timeElapsed = Duration.between(start, finish).toMillis();

		long afterUsedMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();

		long actualMemUsed = afterUsedMem - beforeUsedMem;

		System.out.println(
				"The timetable has been created successfully. (" + timeElapsed + "ms) (" + actualMemUsed + "MB)");

		outputFile(SimulatedAnnealing.getCompatibleSchedule());

		System.out.println("Press any key to exit... ");
		String s = scan.next();
		scan.close();
		System.out.println("Program terminated");
	}
}