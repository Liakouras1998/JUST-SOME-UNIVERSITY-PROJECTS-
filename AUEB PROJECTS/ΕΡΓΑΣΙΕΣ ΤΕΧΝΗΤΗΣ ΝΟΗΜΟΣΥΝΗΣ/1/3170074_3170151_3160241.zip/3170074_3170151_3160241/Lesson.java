
import java.util.Objects;

public class Lesson {

	// ID of lesson
	private String ID;

	// Name of lesson
	private String name;

	// Grade in which the lesson is taught
	private String classes;

	// Hours the lesson has to be taught weekly
	private int hours;

	public Lesson(Lesson lesson) {

		this.ID = lesson.getID();
		this.name = lesson.getName();
		this.classes = lesson.getClasses();
		this.hours = lesson.getHours();
	}

	public Lesson() {

	}

	// Getters
	public String getID() {
		return ID;
	}

	public String getName() {
		return name;
	}

	public String getClasses() {
		return classes;
	}

	public int getHours() {
		return hours;
	}

	// Setters
	public void setID(String ID) {
		this.ID = ID;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setClasses(String classes) {
		this.classes = classes;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		Lesson lesson = (Lesson) o;
		return Objects.equals(ID, lesson.ID);
	}

	@Override
	public String toString() {
		return "Lesson{" + "ID='" + ID + '\'' + ", name='" + name + '\'' + ", classes='" + classes + '\'' + ", hours="
				+ hours + '}';
	}
}