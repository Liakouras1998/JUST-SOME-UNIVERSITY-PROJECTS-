
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

public class Teacher {

	// ID of teacher
	private String ID;

	// Name of teacher
	private String name;

	// ID's of lessons the teacher teaches
	private String[] lessonID;

	// Hours the teacher can work per day and weekly
	private int[] hours;

	// Schedule of teacher
	private Lecture[][] schedule;

	public Teacher(String ID, String name, String[] lessonID, int[] hours) {
		this.ID = ID;
		this.name = name;
		this.lessonID = lessonID;
		this.hours = hours;
		this.schedule = new Lecture[7][5];
		for (int i = 0; i < schedule.length; i++)
			for (int j = 0; j < schedule[0].length; j++)
				schedule[i][j] = null;
	}

	public Teacher() {
		this.schedule = new Lecture[7][5];
		for (int i = 0; i < schedule.length; i++)
			for (int j = 0; j < schedule[0].length; j++)
				schedule[i][j] = null;
	}

	public Teacher(Teacher teacher) {

		this.ID = teacher.getID();
		this.name = teacher.getName();
		setHours(teacher.getHours());
		setLessonID(teacher.getLessonID());

		this.schedule = new Lecture[7][5];
		for (int i = 0; i < schedule.length; i++)
			for (int j = 0; j < schedule[0].length; j++)
				schedule[i][j] = null;
	}

	// Getters
	public String getID() {
		return ID;
	}

	public String getName() {
		return name;
	}

	public String[] getLessonID() {
		return lessonID;
	}

	public int[] getHours() {
		return hours;
	}

	// Setters
	public void setID(String ID) {
		this.ID = ID;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setLessonID(String[] lessonID) {

		this.lessonID = new String[lessonID.length];
		for (int i = 0; i < lessonID.length; i++)
			this.lessonID[i] = lessonID[i];
	}

	public void setHours(int[] hours) {

		this.hours = new int[hours.length];
		for (int i = 0; i < hours.length; i++)
			this.hours[i] = hours[i];
	}

	public void setHours(String[] hours) {

		this.hours = new int[hours.length];
		for (int i = 0; i < hours.length; i++)
			this.hours[i] = Integer.parseInt(hours[i]);
	}

	public void setSchedule() {
		ArrayList<Class> s = SimulatedAnnealing.schedule;

		for (Class c : s)
			for (int i = 0; i < c.getTimetable().length; i++)
				for (int j = 0; j < c.getTimetable()[0].length; j++) {
					if (c.getTimetable()[i][j] != null)
						if ((c.getTimetable()[i][j].getTeacher()).equals(this))
							schedule[i][j] = c.getTimetable()[i][j];
				}
	}

	public int calculateTotalWorkingHours() {
		int counter = 0;
		for (int i = 0; i < schedule.length; i++)
			for (int j = 0; j < schedule[0].length; j++)
				if (schedule[i][j] != null)
					counter++;
		return counter;
	}

	public boolean foundThreeConsecutiveHours(int j) {

		for (int i = 0; i < 5; i++)
			if (schedule[i][j] != null && schedule[i + 1][j] != null && schedule[i + 2][j] != null)
				return true;

		return false;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		Teacher teacher = (Teacher) o;
		return Objects.equals(ID, teacher.ID);
	}

	@Override
	public String toString() {
		return "Teacher{" + "ID='" + ID + '\'' + ", name='" + name + '\'' + ", lessonID=" + Arrays.toString(lessonID)
				+ ", hours=" + Arrays.toString(hours) + '}';
	}
}