import java.util.HashSet;

public interface MachineLearning {

    int classify(HashSet<String> set);
}
