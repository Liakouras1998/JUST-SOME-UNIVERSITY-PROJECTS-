CREATE FUNCTION update_host_listings_count()
  RETURNS trigger AS
'BEGIN
IF TG_OP = ''DELETE'' THEN
 UPDATE Host
SET listings_count = listings_count - 1, 
total_listings_count = total_listings_count - 1,
calculated_listings_count = calculated_listings_count - 1
WHERE id = OLD.host_id;
RETURN OLD;
ELSIF TG_OP = ''INSERT'' THEN
 UPDATE Host
SET listings_count = listings_count + 1,
total_listings_count = total_listings_count + 1,
calculated_listings_count = calculated_listings_count + 1
WHERE id = NEW.host_id;
RETURN NEW;
END IF;
END;
'
LANGUAGE plpgsql;


CREATE TRIGGER host_update AFTER DELETE OR INSERT ON Listing
FOR EACH ROW
EXECUTE PROCEDURE update_host_listings_count();




/*---------------------------------------------------------------
 Το trigger αυτό ενημερώνει το πεδίο number_of_reviews ανάλογα με την διαγραφή/εγγραφή στον πίνακα Review.*/


CREATE FUNCTION update_number_of_reviews()
  RETURNS trigger AS
'BEGIN
IF TG_OP = ''DELETE'' THEN
UPDATE listing 
SET number_of_reviews = number_of_reviews - 1
WHERE id = OLD.listing_id;
RETURN OLD;
ELSIF TG_OP = ''INSERT'' THEN
UPDATE listing 
SET number_of_reviews = number_of_reviews + 1
WHERE id = NEW.listing_id;
RETURN NEW;
END IF;
END;
'
LANGUAGE plpgsql;


CREATE TRIGGER listing_update AFTER DELETE OR INSERT ON Review
FOR EACH ROW
EXECUTE PROCEDURE update_number_of_reviews();




