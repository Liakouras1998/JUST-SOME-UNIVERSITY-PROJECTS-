import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
import psycopg2

# Update connection string information
host = "mydb-3160241-3190122.postgres.database.azure.com"
dbname = "movies"
user = "student241122@mydb-3160241-3190122"
password = "Olympiacos7"
sslmode = "require"

# Construct connection string
conn_string = "host={0} user={1} dbname={2} password={3} sslmode={4}".format(host, user, dbname, password, sslmode)
conn = psycopg2.connect(conn_string)
print("Connection established")

cursor = conn.cursor()

query1 = "select extract(year from release_date) as year, count(*) as number_of_movies from movies_metadata group by year order by year;"
query2 = "select genre ->>'name' as name, count(*) from movies_metadata cross join jsonb_array_elements(genres) genre GROUP BY genre;"
query3 = "select extract(year from release_date) as year, genre ->>'name'  as name , count(genre) from movies_metadata cross join jsonb_array_elements(genres) genre where extract(year from release_date) is not NULL group by genre, year order by year desc, count(distinct genre);"
query4 = "select genre ->> 'name' as name, round(avg(vote_average), 2) as average  from movies_metadata cross join jsonb_array_elements(genres) genre group by genre order by genre;"
query5 = "select distinct userid , count(rating) from ratings group by userid order by userid;"
query6 = "select distinct userid, round(avg(rating),2) from ratings group by userid order by userid;"

cursor.execute(query1)
data1 = cursor.fetchall()
df1 = pd.DataFrame(data1)

cursor.execute(query2)
data2 = cursor.fetchall()
df2 = pd.DataFrame(data2)

cursor.execute(query3)
data3 = cursor.fetchall()
df3 = pd.DataFrame(data3)

cursor.execute(query4)
data4 = cursor.fetchall()
df4 = pd.DataFrame(data4)

cursor.execute(query5)
data5 = cursor.fetchall()
df5 = pd.DataFrame(data5)

cursor.execute(query6)
data6 = cursor.fetchall()
df6 = pd.DataFrame(data6)

df1 = pd.DataFrame(data1)

df2 = pd.DataFrame(data2)

df3 = pd.DataFrame(data3)

df4 = pd.DataFrame(data4)

df5 = pd.DataFrame(data5)

df6 = pd.DataFrame(data6)

x = df1[0]
y = df1[1]

"scatter plot for query 1"
plt.scatter(x,y)
plt.show()

x = df2[0]
y = df2[1]

"scatter plot for query 2"
plt.scatter(y,x)
plt.show()

x = df3[0]
y = df3[1]

"scatter plot for query 3"
plt.scatter(x,y)
plt.show()

x = df4[0]
y = df4[1]

"scatter plot for query 4"
plt.scatter(y,x)
plt.show()

x = df5[0]
y = df5[1]

"scatter plot for query 5"
plt.scatter(y,x)
plt.show()

x = df6[0]
y = df6[1]

"scatter plot for query 6"
plt.scatter(y,x)
plt.show()

cursor.execute("select * from view_table;")
view_data = cursor.fetchall()

view_df = pd.DataFrame(view_data)

x = view_df[1]
y = view_df[2]

"scatter plot for view_table"
plt.scatter(x,y)
plt.show()


conn.commit()
cursor.close()
conn.close()
