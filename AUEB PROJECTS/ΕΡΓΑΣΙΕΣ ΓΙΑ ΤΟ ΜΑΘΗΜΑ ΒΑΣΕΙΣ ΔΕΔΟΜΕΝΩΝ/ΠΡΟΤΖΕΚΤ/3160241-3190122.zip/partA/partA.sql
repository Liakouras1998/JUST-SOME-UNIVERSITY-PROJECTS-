/*

το πεδιο id του πινακα movies_metadata ειναι το tmbdId του πινακα links και οχι το movieId

*/



create table Credits(
   full_cast text,
   crew text,
   id int 
);

create table Keywords(
   id int,
   keywords text
);

create table Links(
   movieId int,
   imdbId int,
   tmdbId numeric 
);

create table Movies_Metadata(
   adult boolean,
   belongs_to_collection varchar(190),
   budget int,
   genres varchar(270),
   homepage varchar(250),
   id int,
   imdb_id varchar(10),
   original_language varchar(10),
   original_title varchar(110),
   overview varchar(1000),
   popularity numeric,
   poster_path varchar(40),
   production_companies varchar(1260),
   production_countries varchar(1040),
   release_date date,
   revenue bigint,
   runtime numeric,
   spoken_languages varchar(770),
   status varchar(20),
   tagline varchar(300),
   title varchar(110),
   video boolean,
   vote_average numeric,
   vote_count int
);

create table Ratings(
   userId int,
   movieId int,
   rating numeric,
   timestamp int
);



alter table links
alter column tmdbid type int using tmdbid::int;

update movies_metadata set imdb_id = replace(imdb_id, 'tt', '');
alter table movies_metadata alter column imdb_id type int using imdb_id::int;

UPDATE 
   movies_metadata
SET 
   genres = REPLACE(genres,E'''', '"');
					
alter table movies_metadata
alter column genres type jsonb USING genres::jsonb;


ALTER TABLE Movies_Metadata ADD PRIMARY KEY (id);

ALTER TABLE Credits ADD PRIMARY KEY (id);
ALTER TABLE Credits ADD CONSTRAINT fkc1 FOREIGN KEY (id) REFERENCES Movies_Metadata (id);

ALTER TABLE Keywords ADD PRIMARY KEY (id);
ALTER TABLE Keywords ADD CONSTRAINT fkk1 FOREIGN KEY (id) REFERENCES Movies_Metadata (id);

ALTER TABLE Links ADD PRIMARY KEY (movieId);
ALTER TABLE Links ADD CONSTRAINT fkl1 FOREIGN KEY (tmdbId) REFERENCES Movies_Metadata (id);

ALTER TABLE Ratings ADD CONSTRAINT fkr1 FOREIGN KEY (movieId) REFERENCES Movies_Metadata (id);