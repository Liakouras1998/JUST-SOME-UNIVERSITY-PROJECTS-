import pandas as pd, sys

if len(sys.argv) != 6:
    print('Invalid number of parameters')
    sys.exit()

credits_data = pd.read_csv(sys.argv[1])
keywords_data = pd.read_csv(sys.argv[2])
links_data = pd.read_csv(sys.argv[3],dtype = {'imdbId':str})
movies_metadata_data = pd.read_csv(sys.argv[4])
ratings_data = pd.read_csv(sys.argv[5])

credits = pd.DataFrame(credits_data)
keywords = pd.DataFrame(keywords_data)
links = pd.DataFrame(links_data)
movies_metadata = pd.DataFrame(movies_metadata_data)
ratings = pd.DataFrame(ratings_data)

credits.drop_duplicates(subset=['id'], keep='first', inplace=True, ignore_index=False)
keywords.drop_duplicates(subset=['id'], keep='first', inplace=True, ignore_index=False)
links.drop_duplicates(subset=['movieId'], keep='first', inplace=True, ignore_index=False)
movies_metadata.drop_duplicates(subset=['id'], keep='first', inplace=True, ignore_index=False)

credits.drop(credits[(~credits.id.isin(movies_metadata.id))].index, inplace = True)
keywords.drop(keywords[(~keywords.id.isin(movies_metadata.id))].index, inplace = True)
links.drop(links[(~links.tmdbId.isin(movies_metadata.id))].index, inplace = True)
ratings.drop(ratings[(~ratings.movieId.isin(movies_metadata.id))].index, inplace = True)

credits.to_csv('credits_2.csv',sep=',',encoding='utf-8',index=False)
keywords.to_csv('keywords_2.csv',sep=',',encoding='utf-8',index=False)
links.to_csv('links_2.csv',sep=',',encoding='utf-8',index=False)
movies_metadata.to_csv('movies_metadata_2.csv',sep=',',encoding='utf-8',index=False)
ratings.to_csv('ratings_2.csv',sep=',',encoding='utf-8',index=False)
