CREATE TABLE Amenity AS
(SELECT DISTINCT UNNEST(amenities::text[]) AS amenity_name FROM room );
 
ALTER  TABLE Amenity
ADD COLUMN amenity_id SERIAL PRIMARY KEY;

CREATE TABLE Room_Amenity AS
(SELECT DISTINCT t.listing_id , amenity.id AS amenity_id FROM amenity,
(SELECT room.listing_id, UNNEST(amenities::text[]) AS amenity_name FROM room ) AS t
 WHERE t.amenity_name = amenity.amenity_name);
 
ALTER TABLE Room_Amenity
ADD PRIMARY KEY(listing_id, amenity_id),
ADD FOREIGN KEY(listing_id) REFERENCES Room(listing_id),
ADD FOREIGN KEY(amenity_id) REFERENCES Amenity(id);

ALTER TABLE Room
DROP COLUMN amenities;