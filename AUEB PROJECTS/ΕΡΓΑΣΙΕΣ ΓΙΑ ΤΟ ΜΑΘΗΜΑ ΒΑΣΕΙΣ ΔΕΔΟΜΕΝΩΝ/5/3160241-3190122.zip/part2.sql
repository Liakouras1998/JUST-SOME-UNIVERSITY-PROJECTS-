


/*
						QUERY 1

Finds the neighbourhoods that have more than 5 non-reviewed listings that cost more than 100 dollars.
Returns the neighbourhoods in descending order.

Rows:15

*/
 
SELECT t.neighbourhood_cleansed, COUNT(t.listing_id)
FROM
(
SELECT p.listing_id, l.neighbourhood_cleansed
FROM Price p
INNER JOIN Location l
ON p.listing_id = l.listing_id
WHERE p.price > 100
) AS t
LEFT OUTER JOIN Review rev
ON t.listing_id = rev.listing_id
WHERE rev.listing_id IS null
GROUP BY t.neighbourhood_cleansed
HAVING COUNT(t.listing_id) > 5
ORDER BY COUNT(t.listing_id) DESC;



/*
						QUERY 2
						
Finds every day with more than 50 available listings bigger than 100 square feet.

Rows:340

*/

 SELECT c.date, COUNT(c.listing_id)
 FROM CalendarCopy c
 INNER JOIN Room r
 ON c.listing_id = r.listing_id
 WHERE c.available = 'true' AND r.square_feet > '100'
 GROUP BY date
 HAVING COUNT(c.listing_id)>50
 ORDER BY COUNT(c.listing_id) DESC;
 
 
 
/*
						QUERY 3
						
Finds every listing with a super host that has no reviews.
		
Rows:260

*/
 
SELECT t.id
FROM Review rev
RIGHT OUTER JOIN 
(
SELECT l.id
FROM Listing l
INNER JOIN Host h
ON l.host_id = h.id
WHERE h.is_superhost = 'true'
) AS t
ON rev.listing_id = t.id 
WHERE rev.listing_id IS null;
 
 
 
/*
						QUERY 4
						
Finds the neighbourhood of every listing that costs more than 500 dollars.
						
Rows:31

*/

SELECT t.neighbourhood_cleansed, p.price
FROM
( 
SELECT l.listing_id, l.neighbourhood_cleansed
FROM Location l
INNER JOIN GeolocationCopy g
ON l.neighbourhood_cleansed = g.properties_neighbourhood
)AS t
INNER JOIN Price p
ON t.listing_id = p.listing_id
WHERE p.price > 500
ORDER BY p.price DESC;


 
 
 
/*
						QUERY 5
						
Finds every listing with a Kitchen, 3 or more bedrooms and 2 or more bathrooms ordered by square_feet
						
Rows:549

*/

SELECT r.listing_id, r.bedrooms, r.bathrooms
FROM Room r
INNER JOIN
(
SELECT ra.listing_id
FROM Amenity a
INNER JOIN Room_Amenity ra
ON a.amenity_id = ra.amenity_id
WHERE a.amenity_name = 'Kitchen'
)AS t
ON r.listing_id = t.listing_id
WHERE r.bedrooms >= '3' AND r.bathrooms >= '2'
ORDER BY r.bathrooms DESC;

 
 
 