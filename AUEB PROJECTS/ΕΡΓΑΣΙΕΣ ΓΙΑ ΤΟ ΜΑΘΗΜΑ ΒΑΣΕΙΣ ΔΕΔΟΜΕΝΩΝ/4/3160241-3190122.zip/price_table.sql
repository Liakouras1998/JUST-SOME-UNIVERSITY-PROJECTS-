CREATE TABLE Price 
AS (SELECT id AS listing_id, price, weekly_price, monthly_price, security_deposit, cleaning_fee,
guests_included, extra_people, minimum_nights, maximum_nights,
minimum_minimum_nights, maximum_minimum_nights, minimum_maximum_nights,
maximum_maximum_nights, minimum_nights_avg_ntm, maximum_nights_avg_ntm 
FROM Listings);


/*

Είχαμε ήδη κάνει replace τα σύμβολα '$' στον πίνακα Calendar και στον πίνακα Listings  ύστερα και απο συζητήσεις με τους 
βοηθούς για να μπορέσουμε να να κάνουμε τα price πεδία τύπου int έτσι ώστε να έχουν τον ίδιο τύπο με τα πεδία price του 
πίνακα Listings_Summary για να μπορούν να γίνουν συγκρίσεις μεταξύ τους αν χρειαστεί στην συνέχεια.'Ετσι κατα την δημιουργία 
του πίνακα Price δεν υπήρχαν τα σύμβολα '$' για να αφαιρεθούν και τα πεδία price ήταν τύπου int.Παρακάτω είναι ο αρχικός κώδικας
που είχε χρησιμοποιηθεί κατα την εργασία 2 για να γίνουν οι αλλαγές στυς πίνακες Calendar και Listings:


UPDATE Calendar
SET 
price= REPLACE(price,'$',''),
adjusted_price= REPLACE(price,'$','');

ALTER TABLE Calendar
ALTER COLUMN price TYPE int USING REPLACE(price,',','')::numeric::int,
ALTER COLUMN adjusted_price TYPE int USING REPLACE(adjusted_price,',','')::numeric::int;

UPDATE Listings
SET 
price= REPLACE(price,'$',''),
weekly_price= REPLACE(weekly_price,'$',''),
monthly_price= REPLACE(monthly_price,'$',''),
security_deposit= REPLACE(security_deposit,'$',''),
cleaning_fee= REPLACE(cleaning_fee,'$',''),
extra_people= REPLACE(extra_people,'$','');

ALTER TABLE Listings
ALTER COLUMN price TYPE int USING REPLACE(price,',','')::numeric::int,
ALTER COLUMN weekly_price TYPE int USING REPLACE(weekly_price,',','')::numeric::int,
ALTER COLUMN monthly_price TYPE int USING REPLACE(monthly_price,',','')::numeric::int,
ALTER COLUMN security_deposit TYPE int USING REPLACE(security_deposit,',','')::numeric::int,
ALTER COLUMN cleaning_fee TYPE int USING REPLACE(cleaning_fee,',','')::numeric::int,
ALTER COLUMN extra_people TYPE int USING REPLACE(extra_people,',','')::numeric::int;


Παραθέτουμε επίσης τον κώδικα που θα είχε χρησιμοποιηθεί για να γίνουν οι αλλαγές αυτές στον πίνακα Price αν δεν τις είχαμε ήδη
κάνει στον πίνακα Calendar(Ο κώδικας αυτός δεν χρησιμοποιήθηκε πουθενά):


UPDATE Price
SET 
price = REPLACE(price,'$',''),
weekly_price = REPLACE(weekly_price,'$',''),
monthly_price = REPLACE(monthly_price,'$',''),
security_deposit = REPLACE(security_deposit,'$',''),
cleaning_fee = REPLACE(cleaning_fee,'$',''),
extra_people= REPLACE(extra_people,'$','');

UPDATE Price
SET 
price = REPLACE(price,',',''),
weekly_price = REPLACE(weekly_price,',',''),
monthly_price = REPLACE(monthly_price,',',''),
security_deposit = REPLACE(security_deposit,',',''),
cleaning_fee = REPLACE(cleaning_fee,',',''),
extra_people= REPLACE(extra_people,',','');


Το αμέσως επόμενο query(δεν είναι σε σχόλια) είναι ή μετατροπή των price πεδίων του πίνακα Price σε numeric που ζητάει η εργασία 4 
(με την διαφορά οτι η μετατροπή γίνεται απο int σε numeric αντι απο varchar που θα γινόταν κανονικά αν δεν είχαμε αλλάξει τους τύπους
στην εργασία 2.(αν και αυτή η διαφορά δεν φαίνεται στο query))

*/


ALTER TABLE Price
ALTER COLUMN price TYPE numeric(10,0) USING price::numeric,
ALTER COLUMN weekly_price TYPE numeric(10,0) USING weekly_price::numeric,
ALTER COLUMN monthly_price TYPE numeric(10,0) USING monthly_price::numeric,
ALTER COLUMN security_deposit TYPE numeric(10,0) USING security_deposit::numeric,
ALTER COLUMN cleaning_fee TYPE numeric(10,0) USING cleaning_fee::numeric,
ALTER COLUMN extra_people TYPE numeric(10,0) USING extra_people::numeric;


ALTER TABLE Price
ADD FOREIGN KEY (listing_id) REFERENCES ListingsCopy(id);


ALTER TABLE ListingsCopy
DROP COLUMN price,
DROP COLUMN weekly_price, 
DROP COLUMN monthly_price, 
DROP COLUMN security_deposit, 
DROP COLUMN cleaning_fee,
DROP COLUMN guests_included, 
DROP COLUMN extra_people, 
DROP COLUMN minimum_nights, 
DROP COLUMN maximum_nights,
DROP COLUMN minimum_minimum_nights, 
DROP COLUMN maximum_minimum_nights, 
DROP COLUMN minimum_maximum_nights,
DROP COLUMN maximum_maximum_nights, 
DROP COLUMN minimum_nights_avg_ntm, 
DROP COLUMN maximum_nights_avg_ntm;