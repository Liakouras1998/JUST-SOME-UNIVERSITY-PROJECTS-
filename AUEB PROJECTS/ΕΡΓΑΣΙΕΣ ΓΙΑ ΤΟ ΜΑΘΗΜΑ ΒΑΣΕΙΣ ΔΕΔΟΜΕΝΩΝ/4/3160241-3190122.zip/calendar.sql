/*

Είχαμε ήδη κάνει replace τα σύμβολα '$' στον πίνακα Calendar(και στον πίνακα Listings) ύστερα και απο συζητήσεις με τους 
βοηθούς για να μπορέσουμε να να κάνουμε τα price πεδία τύπου int έτσι ώστε να έχουν τον ίδιο τύπο με τα πεδία price του 
πίνακα Listings_Summary για να μπορούν να γίνουν συγκρίσεις μεταξύ τους αν χρειαστεί στην συνέχεια.'Ετσι και ο πίνακας
CalendarCopy δεν περιείχε το σύμβολο αυτο.Παρακάτω είναι ο αρχικός κώδικαςπου είχε χρησιμοποιηθεί κατα την εργασία 2 για 
να γίνουν οι αλλαγές στον πίνακα Calendar:


UPDATE Calendar
SET 
price= REPLACE(price,'$',''),
adjusted_price= REPLACE(price,'$','');

ALTER TABLE Calendar
ALTER COLUMN price TYPE int USING REPLACE(price,',','')::numeric::int,
ALTER COLUMN adjusted_price TYPE int USING REPLACE(adjusted_price,',','')::numeric::int;


Το αμέσως επόμενο query(που δεν είναι σε σχόλια) είναι ή μετατροπή των price πεδίων του πίνακα Calendar σε numeric που ζητάει η εργασία 4 
(με την διαφορά οτι η μετατροπή γίνεται απο int σε numeric αντι απο varchar που θα γινόταν κανονικά αν δεν είχαμε αλλάξει τους τύπους
στην εργασία 2(αν και αυτή η διαφορά δεν φαίνεται στο query)) κάθως και η μετατροπή του available σε boolean.

*/


ALTER TABLE CalendarCopy 
ALTER COLUMN price TYPE numeric(10,0) using price::numeric,
ALTER COLUMN adjusted_price TYPE numeric(10,0) using price::numeric;

ALTER TABLE CalendarCopy
ALTER COLUMN available TYPE boolean;