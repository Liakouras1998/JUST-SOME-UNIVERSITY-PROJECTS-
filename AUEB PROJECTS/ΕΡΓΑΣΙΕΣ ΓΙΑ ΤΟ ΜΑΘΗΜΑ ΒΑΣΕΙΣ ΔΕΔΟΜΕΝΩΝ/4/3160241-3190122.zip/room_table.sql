CREATE TABLE Room 
AS (SELECT id AS listing_id, accommodates, bathrooms, bedrooms, beds, bed_type,
amenities, square_feet, price, weekly_price, monthly_price, security_deposit
FROM Listings);


ALTER TABLE Room
ADD FOREIGN KEY (listing_id) REFERENCES ListingsCopy(id);


/*

Τα πεδία weekly_price, monthly_price, security_deposit δεν διαγράφηκαν με το παρακάτω query καθώς χρειάζονται για την δημιουργία 
του πίνακα Price.'Ετσι η διαγραφή των πεδίων αυτών βρίσκεται στο αρχείο price_table.sql ύστερα και απο συνεννόηση με τους βοηθούς.

*/


ALTER TABLE ListingsCopy
DROP COLUMN accommodates, 
DROP COLUMN bathrooms, 
DROP COLUMN bedrooms, 
DROP COLUMN beds, 
DROP COLUMN bed_type,
DROP COLUMN amenities, 
DROP COLUMN square_feet; 
