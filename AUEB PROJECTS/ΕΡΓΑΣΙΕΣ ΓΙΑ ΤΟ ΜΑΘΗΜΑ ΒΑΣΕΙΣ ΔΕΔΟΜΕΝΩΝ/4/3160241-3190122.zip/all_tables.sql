/*

Παρατηρήθηκε πως τα ονόματα των πινάκων ενω στα query γράφονταν με Κεφαλαία στο pgadmin εμφανίζονται με μικρά.
Απο οτι φαίνεται κατα την ονομασία τους θα έπρεπε να υπάρχουν "" όμως στις διαφάνειες και σε μερικά παραδείγματα
(πχ στην εκφώνηση της Εργασίας 3) δεν υπήρχαν οπότε έγιναν έτσι και απο εμάς.'Αν είναι λάθος και στοιχίζει 
μονάδες παρακαλώ ενημερώστε μας στα mail της σχολής αλλιώς πιθανόν να διορθωθεί στην Εργασία 5 που θα έχουν 
γίνει οι έλεγχοι για τις προηγούμενες εργασίες και δεν θα χρειάζονται τα παλιά ονόματα.

*/


ALTER TABLE ListingsCopy
RENAME TO Listing;

ALTER TABLE ReviewsCopy
RENAME TO Review;

ALTER TABLE NeighbourhoodsCopy
RENAME TO Neighbourhood;

ALTER TABLE Listings_SummaryCopy
RENAME TO Listing_Summary;

ALTER TABLE Reviews_SummaryCopy
RENAME TO Review_Summary;


/*

Οι πίνακες CalendarCopy και GeolocationCopy επειδή είναι ήδη στον ενικό έμειναν όπως είναι γιατί υπάρχουν πίνακες
Calendar και Geolocation απο τις προηγούμενες εργασίες που δεν πρέπει να αλλαχθούν.

*/
