BEGIN;
ALTER TABLE Calendar
ADD FOREIGN KEY (listing_id) REFERENCES Listings(id);

ALTER TABLE Listings
ADD FOREIGN KEY (neighbourhood_cleansed) REFERENCES Neighbourhoods(neighbourhood);

ALTER TABLE Listings_Summary
ADD FOREIGN KEY(id) REFERENCES Listings(id);

ALTER TABLE Reviews
ADD FOREIGN KEY (listing_id) REFERENCES Listings(id);

ALTER TABLE Reviews_Summary
ADD FOREIGN KEY (listing_id) REFERENCES Listings(id);

ALTER TABLE Reviews
ADD FOREIGN KEY (listing_id) REFERENCES Listings_Summary(id);

ALTER TABLE Reviews_Summary
ADD FOREIGN KEY (listing_id) REFERENCES Listings_Summary(id);

ALTER TABLE Neighbourhoods
ADD FOREIGN KEY(neighbourhood) REFERENCES Geolocation(properties_neighbourhood);
COMMIT;

UPDATE Calendar
SET 
price= REPLACE(price,'$',''),
adjusted_price= REPLACE(price,'$','');

UPDATE Listings
SET 
price= REPLACE(price,'$',''),
weekly_price= REPLACE(weekly_price,'$',''),
monthly_price= REPLACE(monthly_price,'$',''),
security_deposit= REPLACE(security_deposit,'$',''),
cleaning_fee= REPLACE(cleaning_fee,'$',''),
extra_people= REPLACE(extra_people,'$','');

ALTER TABLE Calendar
ALTER COLUMN price TYPE int USING REPLACE(price,',','')::numeric::int,
ALTER COLUMN adjusted_price TYPE int USING REPLACE(adjusted_price,',','')::numeric::int;

ALTER TABLE Listings
ALTER COLUMN price TYPE int USING REPLACE(price,',','')::numeric::int,
ALTER COLUMN weekly_price TYPE int USING REPLACE(weekly_price,',','')::numeric::int,
ALTER COLUMN monthly_price TYPE int USING REPLACE(monthly_price,',','')::numeric::int,
ALTER COLUMN security_deposit TYPE int USING REPLACE(security_deposit,',','')::numeric::int,
ALTER COLUMN cleaning_fee TYPE int USING REPLACE(cleaning_fee,',','')::numeric::int,
ALTER COLUMN extra_people TYPE int USING REPLACE(extra_people,',','')::numeric::int;
