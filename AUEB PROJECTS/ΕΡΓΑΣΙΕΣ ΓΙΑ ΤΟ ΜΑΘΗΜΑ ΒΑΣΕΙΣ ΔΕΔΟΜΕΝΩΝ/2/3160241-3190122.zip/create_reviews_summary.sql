CREATE TABLE Reviews_Summary(
   listing_id int,
   date date
);