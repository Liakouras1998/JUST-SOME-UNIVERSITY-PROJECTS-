CREATE TABLE Neighbourhoods(
   neighbourhood_group varchar(10),
   neighbourhood varchar(40),
	PRIMARY KEY (neighbourhood)
);