/*
QUERY 1
Finds all the listings with price between 50-150 and 2 beds, ordered by price.
Output:1577
*/

SELECT id
FROM Listings
WHERE price BETWEEN 50 AND 150 AND beds = 2
ORDER BY price ASC;



/*
QUERY 2
Finds the average price of a listing for every neighbourhood, grouped by the neighbourhoods and ordered by price.
Output:45
*/

SELECT neighbourhood_cleansed,ROUND(AVG(price)) AS Average_Price_Of_A_Listing
FROM Listings
GROUP BY neighbourhood_cleansed
ORDER BY Average_Price_Of_A_Listing DESC;



/*
QUERY 3
Finds the minimum and the maximum price for a listing available on '2020-10-01'.
Output:1				
*/

SELECT MIN(L.price) AS Minimum_Price_For_A_Listing, MAX(L.price) AS Maximum_Price_For_A_Listing
FROM Listings L
INNER JOIN Calendar C
ON L.id = C.listing_id
WHERE C.available = true AND C.date = '2020-10-01';



/*
QUERY 4
Finds the 100 cheapest available listings having 'Essentials' listed on their amenities.
Output:100				Output without LIMIT:10224
*/

SELECT DISTINCT L.id,L.neighbourhood_cleansed,L.price
FROM Listings L
INNER JOIN Calendar C
ON L.id = C.listing_id
WHERE amenities LIKE '%Essentials%' AND C.available = 't'
ORDER BY price ASC
LIMIT 100;



/*
QUERY 5
Finds every listing that was reviewd in 2021 by a reviewer called 'George' or 'Andreas'.
Output:892
*/

SELECT L.id,neighbourhood,price,reviewer_name
FROM Listings L
INNER JOIN Reviews R
ON L.id = R.listing_id
WHERE date > '2020-12-31' AND reviewer_name = 'George' OR reviewer_name = 'Andreas';



/*
QUERY 6
Finds every listing that has at least one review and is bigger than 500 square feet and cheaper than 100 dollars.
Output:46
*/

SELECT DISTINCT R.listing_id 
FROM Reviews R
INNER JOIN Listings L
ON R.listing_id = L.id
WHERE CAST(L.square_feet AS int)>500 AND L.price<100
ORDER BY R.listing_id;



/*
QUERY 7
Finds every Entire home/apt listing in 'ΑΜΠΕΛΟΚΗΠΟΙ' that was availabe on the first week of March 2021 and is cheaper than 100,ordered by price. 
Output:188
*/

SELECT Listings.id,Listings.neighbourhood_cleansed,Listings.listing_url,Listings.price
FROM Listings
INNER JOIN (
SELECT DISTINCT Calendar.listing_id
FROM Calendar
WHERE Calendar.available = 't' AND Calendar.date BETWEEN '2021-03-01' AND '2021-03-07') AS NewTable 
ON Listings.id = NewTable.listing_id
WHERE Listings.price<100 AND Listings.neighbourhood_cleansed = 'ΑΜΠΕΛΟΚΗΠΟΙ' AND Listings.room_type = 'Entire home/apt'
ORDER BY price DESC;



/*
QUERY 8
Finds the amount of listings for each neighbourhood,ordered by that amount.
Output:45
*/

SELECT Neighbourhoods.neighbourhood,COUNT(*) AS Listings
FROM Neighbourhoods
INNER JOIN Listings
ON Neighbourhoods.neighbourhood = Listings.neighbourhood_cleansed
GROUP BY Neighbourhoods.neighbourhood
ORDER BY Listings DESC;



/*
QUERY 9
Finds the coordinates for every listing available on '2020-12-31' cheaper than 50 dollars.
Output:3129
*/

SELECT listing_id,properties_neighbourhood,geometry_coordinates_0_0_0_0,geometry_coordinates_0_0_0_1
FROM Geolocation
INNER JOIN (
SELECT listing_id,neighbourhood_cleansed,L.price
FROM Listings L
INNER JOIN Calendar
ON L.id = Calendar.listing_id
WHERE Calendar.available = 't' AND Calendar.date = '2020-12-31') AS New_Table
ON New_Table.neighbourhood_cleansed = Geolocation.properties_neighbourhood
WHERE price<50;



/*
QUERY 10
Finds every listing with a superhost who has been described as 'friendly'.
Output:13816
*/

SELECT Listings.id,neighbourhood,picture_url,host_name,price
FROM Listings
INNER JOIN Reviews
ON Listings.id = Reviews.listing_id
WHERE Listings.host_is_superhost = 'true' AND Reviews.comments LIKE '%friendly%';



/*
QUERY 11
Finds the listings with more than 3 bedrooms that have no reviews.
Output:47
*/

SELECT L.*
FROM Reviews R
RIGHT OUTER JOIN Listings L
ON R.listing_id = L.id
WHERE R.listing_id IS null AND L.bedrooms>3;



/*
QUERY 12
Find the number of listings thad don't have reviews.
Output:1
*/

SELECT COUNT(*) AS Number_Of_Listings_Without_Reviews
FROM (
SELECT L.id, R.listing_id 
FROM  Listings L 
LEFT OUTER JOIN Reviews R
ON L.id = R.listing_id) AS New_Table
WHERE New_Table.listing_id IS null ;

